# IPTV Player (versión básica)

App original en Kotlin + Media3 (ExoPlayer) optimizada para reproducción fluida.

## Cómo generar el APK

1. Abrí **Android Studio**
2. File → Open → seleccioná la carpeta `IptvPlayer`
3. Esperá que Gradle sincronice
4. Conectá tu celular o usá un emulador
5. Hacé clic en el botón **Run** (▶️)

### Para generar APK instalable:
- Build → Build Bundle(s) / APK(s) → Build APK(s)
- El APK queda en `app/build/outputs/apk/debug/app-debug.apk`

## Características de esta versión

- Carga listas M3U desde URL
- Lista de canales
- Reproducción con Media3 + preferencia de hardware decoding
- Buffer generoso (menos cortes)
- Interfaz oscura simple

## Próximos pasos posibles

- Soporte Xtream Codes
- Categorías / grupos
- Favoritos
- EPG
- Versión optimizada para Android TV
