package com.iptv.player

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.iptv.player.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var channels: List<Channel> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerChannels.layoutManager = LinearLayoutManager(this)

        binding.btnLoad.setOnClickListener {
            val url = binding.etPlaylistUrl.text.toString().trim()
            if (url.isEmpty()) {
                Toast.makeText(this, "Pegá una URL de lista M3U", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            loadPlaylist(url)
        }
    }

    private fun loadPlaylist(urlString: String) {
        binding.progress.visibility = View.VISIBLE
        binding.btnLoad.isEnabled = false

        lifecycleScope.launch {
            try {
                val content = withContext(Dispatchers.IO) {
                    val url = URL(urlString)
                    val connection = url.openConnection() as HttpURLConnection
                    connection.connectTimeout = 15000
                    connection.readTimeout = 15000
                    connection.requestMethod = "GET"
                    connection.setRequestProperty("User-Agent", "IPTVPlayer/1.0")
                    connection.inputStream.bufferedReader().use { it.readText() }
                }

                channels = M3UParser.parse(content)

                withContext(Dispatchers.Main) {
                    binding.progress.visibility = View.GONE
                    binding.btnLoad.isEnabled = true

                    if (channels.isEmpty()) {
                        Toast.makeText(this@MainActivity, "No se encontraron canales", Toast.LENGTH_LONG).show()
                        return@withContext
                    }

                    binding.tvStatus.text = "${channels.size} canales cargados"
                    binding.recyclerChannels.adapter = ChannelAdapter(channels) { channel ->
                        openPlayer(channel)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.progress.visibility = View.GONE
                    binding.btnLoad.isEnabled = true
                    Toast.makeText(
                        this@MainActivity,
                        "Error al cargar: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun openPlayer(channel: Channel) {
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra("CHANNEL_NAME", channel.name)
            putExtra("CHANNEL_URL", channel.url)
        }
        startActivity(intent)
    }
}
