package com.iptv.player

object M3UParser {

    fun parse(content: String): List<Channel> {
        val channels = mutableListOf<Channel>()
        val lines = content.lines()

        var currentName = ""
        var currentLogo: String? = null
        var currentGroup: String? = null

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.startsWith("#EXTINF:", ignoreCase = true)) {
                // Ejemplo: #EXTINF:-1 tvg-logo="..." group-title="...",Nombre del canal
                currentName = trimmed.substringAfterLast(",").trim()
                currentLogo = extractAttribute(trimmed, "tvg-logo")
                currentGroup = extractAttribute(trimmed, "group-title")
            } else if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                if (currentName.isNotEmpty()) {
                    channels.add(
                        Channel(
                            name = currentName,
                            url = trimmed,
                            logo = currentLogo,
                            group = currentGroup
                        )
                    )
                }
                currentName = ""
                currentLogo = null
                currentGroup = null
            }
        }
        return channels
    }

    private fun extractAttribute(line: String, attr: String): String? {
        val regex = """$attr="([^"]*)"""".toRegex(RegexOption.IGNORE_CASE)
        return regex.find(line)?.groupValues?.get(1)
    }
}
